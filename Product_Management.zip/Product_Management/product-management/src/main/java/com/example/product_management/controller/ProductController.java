package com.example.product_management.controller;

import com.example.product_management.model.Product;
import com.example.product_management.model.ProductAttribute;
import com.example.product_management.model.Attribute;
import com.example.product_management.model.Category;
import com.example.product_management.service.ProductService;
import com.example.product_management.service.CategoryService;
import com.example.product_management.service.AttributeService;
import com.example.product_management.service.ProductAttributeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller  // REMOVED: @RequestMapping("/products")
public class ProductController {
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private CategoryService categoryService;
    
    @Autowired
    private AttributeService attributeService;
    
    @Autowired
    private ProductAttributeService productAttributeService;
    
    
    
    @GetMapping("/products")
    public String getAllProducts(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("product", new Product());
        return "products";
    }
    
    @GetMapping("/products/category/{categoryId}")
    public String getProductsByCategory(@PathVariable Long categoryId, Model model) {
        model.addAttribute("products", productService.getProductsByCategoryId(categoryId));
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("product", new Product());
        model.addAttribute("categoryAttributes", attributeService.getAttributesByCategoryId(categoryId));
        return "products";
    }
    
    @GetMapping("/products/{id}")
    public String getProductDetails(@PathVariable Long id, Model model) {
        Product product = productService.getProductById(id)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
        
        List<ProductAttribute> productAttributes = productAttributeService.getProductAttributesByProductId(id);
        
        model.addAttribute("product", product);
        model.addAttribute("productAttributes", productAttributes);
        model.addAttribute("allAttributes", attributeService.getAttributesByCategoryId(product.getCategory().getCategoryId()));
        
        return "product-details";
    }
    
    @GetMapping("/products/{id}/attributes")
    public String manageProductAttributes(@PathVariable Long id, Model model) {
        Product product = productService.getProductById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        
        List<Attribute> availableAttributes = attributeService.getAttributesByCategoryId(
                product.getCategory().getCategoryId());
        List<ProductAttribute> currentAttributes = productAttributeService.getProductAttributesByProductId(id);
        
        model.addAttribute("product", product);
        model.addAttribute("availableAttributes", availableAttributes);
        model.addAttribute("currentAttributes", currentAttributes);
        
        return "product-attributes";
    }
    
    @PostMapping("/products")
    public String createProduct(@ModelAttribute Product product, 
                              @RequestParam Long categoryId) {
        // Get the category from the ID and set it on the product
        Category category = categoryService.getCategoryById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        product.setCategory(category);
        productService.createProduct(product);
        return "redirect:/products";
    }
    
    @PostMapping("/products/{productId}/attributes")
    public String addProductAttribute(@PathVariable Long productId,
                                    @RequestParam Long attributeId,
                                    @RequestParam String attributeValue) {
        
        Product product = productService.getProductById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        
        Attribute attribute = attributeService.getAttributeById(attributeId)
                .orElseThrow(() -> new RuntimeException("Attribute not found"));
        
        // Check if this attribute already exists for the product
        ProductAttribute existing = productAttributeService.getProductAttributeByProductAndAttribute(
                productId, attributeId);
        
        if (existing != null) {
            // Update existing
            existing.setAttributeValue(attributeValue);
            productAttributeService.updateProductAttribute(existing.getProductAttributeId(), existing);
        } else {
            // Create new
            ProductAttribute productAttribute = new ProductAttribute();
            productAttribute.setProduct(product);
            productAttribute.setAttribute(attribute);
            productAttribute.setAttributeValue(attributeValue);
            productAttributeService.createProductAttribute(productAttribute);
        }
        
        return "redirect:/products/" + productId + "/attributes";
    }
    
    @PostMapping("/products/{id}")
    public String updateProduct(@PathVariable Long id, @ModelAttribute Product product) {
        productService.updateProduct(id, product);
        return "redirect:/products";
    }
    
    @PostMapping("/products/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "redirect:/products";
    }
    
    @PostMapping("/products/attributes/delete/{id}")
    public String deleteProductAttribute(@PathVariable Long id) {
        ProductAttribute productAttribute = productAttributeService.getProductAttributeById(id)
                .orElseThrow(() -> new RuntimeException("Product attribute not found"));
        
        Long productId = productAttribute.getProduct().getProductId();
        productAttributeService.deleteProductAttribute(id);
        
        return "redirect:/products/" + productId + "/attributes";
    }
}