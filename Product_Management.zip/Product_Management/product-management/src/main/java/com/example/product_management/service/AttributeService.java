package com.example.product_management.service;

import com.example.product_management.model.Attribute;
import com.example.product_management.repository.AttributeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AttributeService {
    
    @Autowired
    private AttributeRepository attributeRepository;
    
    public List<Attribute> getAllAttributes() {
        return attributeRepository.findAll();
    }
    
    public List<Attribute> getAttributesByCategoryId(Long categoryId) {
        return attributeRepository.findByCategory_CategoryId(categoryId);
    }
    
    public Optional<Attribute> getAttributeById(Long id) {
        return attributeRepository.findById(id);
    }
    
    public Attribute createAttribute(Attribute attribute) {
        return attributeRepository.save(attribute);
    }
    
    public Attribute updateAttribute(Long id, Attribute attributeDetails) {
        Attribute attribute = attributeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Attribute not found with id: " + id));
        
        attribute.setAttributeName(attributeDetails.getAttributeName());
        attribute.setCategory(attributeDetails.getCategory());
        
        return attributeRepository.save(attribute);
    }
    
    public void deleteAttribute(Long id) {
        Attribute attribute = attributeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Attribute not found with id: " + id));
        
        attributeRepository.delete(attribute);
    }
}