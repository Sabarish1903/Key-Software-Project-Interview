package com.example.product_management.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "attributes")
@Data
public class Attribute {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attributeId;
    
    @Column(nullable = false)
    private String attributeName;
    
    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;
}