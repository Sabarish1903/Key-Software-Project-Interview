package com.example.product_management.controller;

import com.example.product_management.model.Attribute;
import com.example.product_management.service.AttributeService;
import com.example.product_management.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/attributes")
public class AttributeController {
    
    @Autowired
    private AttributeService attributeService;
    
    @Autowired
    private CategoryService categoryService;
    
    @GetMapping
    public String getAllAttributes(Model model) {
        model.addAttribute("attributes", attributeService.getAllAttributes());
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("attribute", new Attribute());
        return "attributes";
    }
    
    @GetMapping("/category/{categoryId}")
    public String getAttributesByCategory(@PathVariable Long categoryId, Model model) {
        model.addAttribute("attributes", attributeService.getAttributesByCategoryId(categoryId));
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("attribute", new Attribute());
        return "attributes";
    }
    
    @PostMapping
    public String createAttribute(@ModelAttribute Attribute attribute) {
        attributeService.createAttribute(attribute);
        return "redirect:/attributes";
    }
    
    @PostMapping("/{id}")
    public String updateAttribute(@PathVariable Long id, @ModelAttribute Attribute attribute) {
        attributeService.updateAttribute(id, attribute);
        return "redirect:/attributes";
    }
    
    @PostMapping("/delete/{id}")
    public String deleteAttribute(@PathVariable Long id) {
        attributeService.deleteAttribute(id);
        return "redirect:/attributes";
    }
}