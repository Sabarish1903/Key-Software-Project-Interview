package com.example.product_management;

import com.example.product_management.model.Category;
import com.example.product_management.model.Attribute;
import com.example.product_management.model.Product;
import com.example.product_management.repository.CategoryRepository;
import com.example.product_management.repository.AttributeRepository;
import com.example.product_management.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataLoader implements CommandLineRunner {
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private AttributeRepository attributeRepository;
    
    @Autowired
    private ProductRepository productRepository;
    
    @Override
    public void run(String... args) throws Exception {
        // Create sample categories
        Category dresses = new Category();
        dresses.setCategoryName("Dresses");
        dresses.setDescription("Women's dresses for all occasions");
        categoryRepository.save(dresses);
        
        Category shoes = new Category();
        shoes.setCategoryName("Shoes");
        shoes.setDescription("Footwear for men and women");
        categoryRepository.save(shoes);
        
        Category watches = new Category();
        watches.setCategoryName("Watches");
        watches.setDescription("Luxury and casual watches");
        categoryRepository.save(watches);
        
        // Create sample attributes for dresses
        Attribute dressSize = new Attribute();
        dressSize.setAttributeName("Size");
        dressSize.setCategory(dresses);
        attributeRepository.save(dressSize);
        
        Attribute dressColor = new Attribute();
        dressColor.setAttributeName("Color");
        dressColor.setCategory(dresses);
        attributeRepository.save(dressColor);
        
        Attribute dressMaterial = new Attribute();
        dressMaterial.setAttributeName("Material");
        dressMaterial.setCategory(dresses);
        attributeRepository.save(dressMaterial);
        
        // Create sample attributes for shoes
        Attribute shoeSize = new Attribute();
        shoeSize.setAttributeName("Shoe Size");
        shoeSize.setCategory(shoes);
        attributeRepository.save(shoeSize);
        
        Attribute shoeColor = new Attribute();
        shoeColor.setAttributeName("Color");
        shoeColor.setCategory(shoes);
        attributeRepository.save(shoeColor);
        
        Attribute shoeType = new Attribute();
        shoeType.setAttributeName("Type");
        shoeType.setCategory(shoes);
        attributeRepository.save(shoeType);
        
        // Create sample attributes for watches
        Attribute watchMovement = new Attribute();
        watchMovement.setAttributeName("Movement");
        watchMovement.setCategory(watches);
        attributeRepository.save(watchMovement);
        
        Attribute watchDialColor = new Attribute();
        watchDialColor.setAttributeName("Dial Color");
        watchDialColor.setCategory(watches);
        attributeRepository.save(watchDialColor);
        
        Attribute watchWaterResistant = new Attribute();
        watchWaterResistant.setAttributeName("Water Resistant");
        watchWaterResistant.setCategory(watches);
        attributeRepository.save(watchWaterResistant);
        
        // Create sample products
        Product summerDress = new Product();
        summerDress.setProductName("Summer Floral Dress");
        summerDress.setSku("DRS001");
        summerDress.setPrice(new BigDecimal("49.99"));
        summerDress.setCategory(dresses);
        productRepository.save(summerDress);
        
        Product runningShoes = new Product();
        runningShoes.setProductName("Running Shoes");
        runningShoes.setSku("SHO001");
        runningShoes.setPrice(new BigDecimal("89.99"));
        runningShoes.setCategory(shoes);
        productRepository.save(runningShoes);
        
        Product luxuryWatch = new Product();
        luxuryWatch.setProductName("Luxury Chronograph Watch");
        luxuryWatch.setSku("WAT001");
        luxuryWatch.setPrice(new BigDecimal("299.99"));
        luxuryWatch.setCategory(watches);
        productRepository.save(luxuryWatch);
    }
}