// ProductAttributeService.java
package com.example.product_management.service;

import com.example.product_management.model.ProductAttribute;
import com.example.product_management.repository.ProductAttributeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ProductAttributeService {
    
    @Autowired
    private ProductAttributeRepository productAttributeRepository;
    
    public List<ProductAttribute> getProductAttributesByProductId(Long productId) {
        return productAttributeRepository.findByProduct_ProductId(productId);
    }
    
    public Optional<ProductAttribute> getProductAttributeById(Long id) {
        return productAttributeRepository.findById(id);
    }
    
    public ProductAttribute createProductAttribute(ProductAttribute productAttribute) {
        return productAttributeRepository.save(productAttribute);
    }
    
    public ProductAttribute updateProductAttribute(Long id, ProductAttribute productAttributeDetails) {
        ProductAttribute productAttribute = productAttributeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("ProductAttribute not found with id: " + id));
        
        productAttribute.setAttributeValue(productAttributeDetails.getAttributeValue());
        
        return productAttributeRepository.save(productAttribute);
    }
    
    public void deleteProductAttribute(Long id) {
        ProductAttribute productAttribute = productAttributeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("ProductAttribute not found with id: " + id));
        
        productAttributeRepository.delete(productAttribute);
    }
    
    public ProductAttribute getProductAttributeByProductAndAttribute(Long productId, Long attributeId) {
        return productAttributeRepository.findByProduct_ProductIdAndAttribute_AttributeId(productId, attributeId);
    }
}