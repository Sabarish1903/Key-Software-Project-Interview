package com.example.product_management.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "products_attributes")
@Data
public class ProductAttribute {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productAttributeId;
    
    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;
    
    @ManyToOne
    @JoinColumn(name = "attribute_id", nullable = false)
    private Attribute attribute;
    
    @Column(nullable = false)
    private String attributeValue;
}